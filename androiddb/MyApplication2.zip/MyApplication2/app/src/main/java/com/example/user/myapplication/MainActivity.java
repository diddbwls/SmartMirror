package com.example.user.myapplication;

import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DBhelper dbhelper;
    EditText edtName, edtNumber, edtNameResult, edtAgeResult;
    Button init, insert, select;
    SQLiteDatabase db;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("스마트미러 회원가입");

        edtName = (EditText) findViewById(R.id.edtName);
        edtNumber = (EditText) findViewById(R.id.edtNumber);
        edtNameResult = (EditText) findViewById(R.id.edtNameResult);
        edtAgeResult = (EditText) findViewById(R.id.edtAgeResult);
        init = (Button) findViewById(R.id.init);
        insert = (Button) findViewById(R.id.insert);
        select = (Button) findViewById(R.id.select);
        dbhelper = new DBhelper(this);
        init.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                db = dbhelper.getWritableDatabase();
                dbhelper.onUpgrade(db, 1, 2);
                db.close();
                edtNameResult.setText("새테이블 생성 성공");
                edtAgeResult.setText("");
                Toast.makeText(getApplicationContext(), "새테이블 생성 성공",
                        Toast.LENGTH_LONG).show();

            }
        });
        insert.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                db = dbhelper.getWritableDatabase();
                String sql = "insert into grouptable values('" + edtName.getText().toString() + "',"
                        + edtNumber.getText().toString() + ");";
                db.execSQL(sql);

                String name = edtName.getText().toString();
                String number = edtNumber.getText().toString();
                Integer num = Integer.parseInt(number);
                sql = "insert into grouptable values('" + name + "'," + num + ");";
                db.execSQL(sql);

                db.close();
                Toast.makeText(getApplicationContext(), "입력됨",
                        Toast.LENGTH_SHORT).show();
            }
        });

        select.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                db = dbhelper.getReadableDatabase();
                Cursor cursor;
                cursor = db.rawQuery("select * from grouptable;", null);
                String strNames = "사용자 이름" + "\r\n";
                String strNumbers = "나이" + "\r\n" ;

                while (cursor.moveToNext()) {
                    strNames += cursor.getString(0) + "\r\n";
                    strNumbers += cursor.getString(1) + "\r\n";
                }
                edtNameResult.setText(strNames);
                edtAgeResult.setText(strNumbers);
                cursor.close();
                db.close();
            }
        });
    }

    public class DBhelper extends SQLiteOpenHelper {
        public DBhelper(Context context) {
            super(context, "groupDB", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table grouptable ( gName CHAR(20) , gNumber INTEGER);");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table if exists grouptable");
            onCreate(db);
        }
    }
}